# Design Guide: Collabo (Precision Pulse)

## 1. Creative North Star: "The Digital Architect’s Journal"
This design system is built upon the philosophy of precision editorial. It treats social planning not just as a task, but as a curated experience. It balances professional-grade structure with vibrant, high-energy accents to keep the process feeling dynamic and engaging.

## 2. Visual Foundation

### Color Palette
- **Primary:** `#3459d4` (Reliable Blue) - Used for primary actions, branding, and core navigation elements.
- **Secondary:** `#a92876` (Vibrant Magenta) - Used for urgency, high-priority status, and energetic accents.
- **Tertiary:** `#458a9a` (Professional Teal) - Used for secondary highlights, success states, and calm informational elements.
- **Neutral:** `#e8e8e8` (Cool Grey) - Used for backgrounds, card containers, and structural separation.
- **Surface:** `#ffffff` (White) - Used for primary content areas to ensure maximum readability.

### Typography
- **Primary Font:** `Plus Jakarta SANS`
- **Headlines:** Tracking-tight, semi-bold to bold. Designed to feel like a modern magazine header.
- **Body:** Clean, sans-serif with ample line height for readability.
- **Micro-copy:** Uppercase with wide tracking for labels and metadata (e.g., "URGENT", "IN PROGRESS").

### Shape & Structure
- **Roundness:** `ROUND_EIGHT` (8px corner radius) - Provides a balanced feel that is modern without being overly soft.
- **Layout:** Editorial-style spacing with generous white space and clear visual hierarchy.
- **Elevation:** Flat design with subtle tonal shifts instead of heavy shadows to maintain a clean, high-end feel.

## 3. Core Components

### Top App Bar
- **Style:** Small, center-aligned.
- **Branding:** "COLLABO" in bold, uppercase blue.
- **Separation:** Tonal background shift to distinguish the header from content.

### Bottom Navigation
- **Style:** Label + Icon.
- **Active State:** High-contrast blue with rounded-full backgrounds for the active tab.
- **Inactive State:** Muted grey to keep focus on the active area.

### Planning Cards
- **Structure:** Clear status badges at the top-left (e.g., "URGENT", "IN PROGRESS").
- **Assignments:** Prominent user avatars to show task ownership.
- **Interactions:** Subtle scale transitions on hover/tap.

## 4. Design Principles
1. **Precision First:** Every element should have a clear purpose and place.
2. **Editorial Energy:** Use the secondary magenta and tertiary teal to inject life into the structured layout.
3. **Collaborative Clarity:** Ensure that who is doing what is always immediately obvious through avatars and clear task status.
