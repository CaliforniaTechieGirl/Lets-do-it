# Design System Strategy: Precision Editorial

## 1. Overview & Creative North Star
**The Creative North Star: "The Digital Architect’s Journal"**

This design system is built upon the philosophy of **Precision Editorial**. It rejects the cluttered, line-heavy interfaces of traditional productivity tools in favor of a high-end, magazine-inspired digital experience. We move beyond the "template" look by prioritizing intentional white space, dramatic typographic scale, and a sophisticated layering system.

The goal is to marry the clinical reliability of a data-driven tool with the fluid, kinetic energy of a premium social platform. We achieve this through:
*   **Asymmetric Balance:** Using generous, purposeful negative space to guide the eye.
*   **Tonal Architecture:** Defining structure through color shifts rather than physical lines.
*   **Kinetic Typography:** Treating text not just as information, but as a primary visual element that breathes and commands attention.

---

## 2. Color Theory & Tonal Layering
The palette is a sophisticated blend of "Reliable Blue" and "Energetic Magenta," anchored by a neutral foundation that favors soft light greys over stark whites.

### The "No-Line" Rule
**Borders are strictly prohibited for sectioning.** To separate content, designers must use background color shifts or tonal transitions. A container should never be "outlined"; it should be "revealed" by sitting on a contrasting surface tier (e.g., a `surface_container_lowest` card sitting on a `surface_container` background).

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of fine vellum. 
*   **Base:** `surface` (#f9f9f9)
*   **Primary Containers:** `surface_container_low` (#f4f3f3) for subtle grouping.
*   **Active Elements:** `surface_container_lowest` (#ffffff) for the highest elevation and focus.
*   **Depth shifts:** Use `surface_container_high` (#e8e8e8) for utility bars or secondary navigation to create a "recessed" feel.

### The Glass & Gradient Rule
To inject "soul" into the professional framework:
*   **Signature Gradients:** For Hero sections or primary CTAs, blend `primary` (#0e3ebb) into `primary_container` (#3459d4) at a 135-degree angle.
*   **Glassmorphism:** Floating menus or modals must use semi-transparent `surface_container_lowest` with a 20px backdrop blur to ensure the UI feels integrated and ethereal rather than heavy.

---

## 3. Typography: The Editorial Voice
We use **Plus Jakarta Sans** as our sole typeface. Its modern, geometric curves provide the "Precision" while its open counters provide the "Pulse."

*   **Display (lg/md):** Reserved for high-impact editorial moments. Use `-0.02em` letter spacing to create a tight, professional "locked-in" look.
*   **Headlines:** Large and authoritative. Use `headline-lg` (2rem) for page titles to establish a clear starting point.
*   **Body (md):** The workhorse. Set at `0.875rem` for data-dense areas to maintain the productivity tool aesthetic.
*   **Labels:** Use `label-md` in uppercase with `0.05em` tracking for a "Swiss-style" utility feel in small UI elements.

**Hierarchy Tip:** Contrast a `display-md` headline with a `body-sm` caption nearby. The drastic jump in scale is what creates the "Editorial" feel.

---

## 4. Elevation & Depth
In this design system, depth is felt, not seen.

### The Layering Principle
Avoid "Drop Shadows" as a default. Instead, use **Tonal Stacking**:
1.  **Level 0 (Background):** `surface`
2.  **Level 1 (Section):** `surface_container_low`
3.  **Level 2 (Card):** `surface_container_lowest` (Pure white)

### Ambient Shadows
When a component must float (e.g., a dropdown or a floating action button), use an **Ambient Shadow**:
*   **Blur:** 32px to 64px.
*   **Spread:** -4px.
*   **Opacity:** 4–8%.
*   **Color:** Use a tinted version of `on_surface` (#1a1c1c) to ensure the shadow looks like natural light occlusion, not a grey smudge.

### The "Ghost Border" Fallback
If a border is required for accessibility (e.g., input fields), use a **Ghost Border**: `outline_variant` (#c4c5d6) at 20% opacity. Never use 100% opaque borders.

---

## 5. Components

### Buttons: The Kinetic Anchor
*   **Primary:** A solid `primary` (#0e3ebb) background with `on_primary` text. Use the `xl` (1.5rem) roundedness for a pill-shaped, approachable feel.
*   **Secondary:** Use the `secondary_container` (#ff70be) with `on_secondary_container` text for high-energy actions.
*   **Tertiary:** No background. Use `primary` text weight 600.

### Input Fields
*   **Style:** Background set to `surface_container_highest` (#e2e2e2) with a bottom-only "Ghost Border."
*   **Focus State:** Transition the background to `primary_fixed` (#dce1ff) with a subtle 2px `primary` indicator on the left edge.

### Cards & Lists
*   **Rule:** Forbid divider lines. 
*   **Execution:** Use `body-lg` spacing (1rem) between items. To separate list items, use a background hover state of `surface_container_low`.
*   **Cards:** Use `lg` (1rem) corner radius. Use Tonal Layering (White card on Grey background) to define the container.

### Signature Component: The "Editorial Header"
A layout pattern where the `display-sm` title is offset to the left, while the `body-md` description sits in a narrow column to the right, creating an asymmetric, professional magazine layout.

---

## 6. Do's and Don'ts

### Do
*   **Do** use `secondary` (#a92876) sparingly as an "accent pulse" for notifications or active states.
*   **Do** embrace asymmetric layouts where the left margin is wider than the right.
*   **Do** use `tertiary` (#005462) for "Calm" utility areas like settings, filters, or footers.

### Don't
*   **Don't** use 1px solid black or dark grey borders. Ever.
*   **Don't** use standard "Material Design" shadows. Keep them diffused and light.
*   **Don't** cram content. If a screen feels full, increase the `surface` whitespace by 20%.
*   **Don't** use pure black (#000000) for text. Always use `on_surface` (#1a1c1c) for a softer, premium feel.